package pe.edu.upc.model.dao;

import java.util.ArrayList;
import java.util.List;

import pe.edu.upc.model.entity.Persona;
import pe.edu.upc.service.IPersona;


public class ListaPersonas {

	
	
}
