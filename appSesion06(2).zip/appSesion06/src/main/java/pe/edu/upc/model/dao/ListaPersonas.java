package pe.edu.upc.model.dao;

import java.util.ArrayList;
import java.util.List;

import pe.edu.upc.model.entity.Persona;
import pe.edu.upc.service.IPersona;


public class ListaPersonas implements IPersona {

	public int contar() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Persona obtenerElemento(int pos) {
		// TODO Auto-generated method stub
		return null;
	}

	public String insertar(Persona o) {
		// TODO Auto-generated method stub
		return null;
	}

	public Persona buscarporDNI(String DNI) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
